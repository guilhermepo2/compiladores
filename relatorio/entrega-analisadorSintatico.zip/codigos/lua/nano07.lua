-- Listagem 7: Inclusao do comando condicional
n = 1
if (n == 1)
then
	print(n)
end