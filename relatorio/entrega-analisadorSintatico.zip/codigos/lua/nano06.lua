-- Listagem 6: Atribuicao de uma subtracao de inteiros a uma variavel

n = 1 - 2
print(n)