-- Listagem 11: Introducao do comando de repeticao enquanto
n = 1
m = 2
x = 5

while(x > n)
do
	n = n + m
	print(n)
end