-- Listagem 2: Declaracao de uma variavel

-- Em Lua, declaracao de variaveis limitam apenas seu escopo
-- As variaveis podem ser local ou global
-- local: local x = 10 - precisam ser inicializadas
-- global: x = 10      - nao precisam ser inicializadas
-- local x          e um programa aceito em lua (declaracao de uma variavel local)
-- x                nao e um programa aceito em lua