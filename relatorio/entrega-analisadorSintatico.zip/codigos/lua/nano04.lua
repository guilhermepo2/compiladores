-- Atribuicao de uma soma de inteiros a uma variavel
n = 1 + 2