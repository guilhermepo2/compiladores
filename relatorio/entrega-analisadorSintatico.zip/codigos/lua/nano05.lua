-- Inclusao do comando de impressao
n = 2
print(n)