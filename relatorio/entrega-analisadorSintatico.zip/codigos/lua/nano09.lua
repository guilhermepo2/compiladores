-- Listagem 9: Atribuicao de duas operacoes aritmeticas sobre inteiros a uma variavel

n = 1 + 1 / 2
if (n == 1)
then
	print(n)
else
	print("0")
end