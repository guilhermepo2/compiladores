puts("Digite a venda:")
venda = gets.chomp.to_f

puts(venda)
