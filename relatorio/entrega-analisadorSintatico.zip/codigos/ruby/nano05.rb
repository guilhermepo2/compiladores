# Inclusao do comando de impressao
n = 2
puts(n)
