# modulo minimo
