# Introducao do comando de repeticao enquanto
n = 1
m = 2
x = 5

while x > n
  n = n + m
  puts(n)
end
  
