# atribuicao de soma de inteiros a uma variavel
n = 1 + 2
