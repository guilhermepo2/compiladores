# Inclusao do comando condicional com parte senao

n = 1
if n == 1
  puts(n)
else
  puts("0")
end
