# atribuicao de duas variaveis inteiras
n = 1
m = 2

if n == m
  puts(n)
else
  puts("0")
end
