# Subtracao de inteiros

n = 1 - 2
puts(n)
