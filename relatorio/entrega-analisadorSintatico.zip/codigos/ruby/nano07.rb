# Inclusao de condicional
n = 1
if n == 1
  puts(n)
end
