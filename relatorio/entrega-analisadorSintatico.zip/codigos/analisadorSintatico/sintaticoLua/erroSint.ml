
(* This file was auto-generated based on "sintatico.msg". *)

(* Please note that the function [message] can raise [Not_found]. *)

let message =
  fun s ->
    match s with
    | 1 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 193 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 194 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 195 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 0 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 152 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 50 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 51 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 49 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 67 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 68 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 153 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 198 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 23 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 183 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 184 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 182 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 147 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 25 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 15 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 17 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 14 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 26 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 27 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 104 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 105 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 106 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 169 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 170 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 171 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 172 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 180 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 175 ->
        "Erro apos else.\n"
    | 177 ->
        "Esperava um END\n"
    | 35 ->
        "Erro apos operador unario.\n"
    | 78 ->
        "Esperava operador binario ou erro apos operador unario.\n"
    | 37 ->
        "Esperava argumentos, colchete ou ID.\n"
    | 11 ->
        "Erro apos declaracao de funcao.\n"
    | 12 ->
        "Erro apos abertura de parentese.\n"
    | 21 ->
        "Esperava um fecha parentese.\n"
    | 187 ->
        "Esperava uma lista de nomes.\n"
    | 22 ->
        "Esperava um bloco.\n"
    | 185 ->
        "Esperava um END.\n"
    | 31 ->
        "Esperava uma lista de campos.\n"
    | 98 ->
        "Esperava um operador binario ou virgula, ponto e virgula ou fecha chaves.\n"
    | 96 ->
        "Esperava um virgula, ponto e virgula ou fecha chaves.\n"
    | 32 ->
        "Erro apos declaracao de variavel.\n"
    | 33 ->
        "Esperava uma expressao.\n"
    | 79 ->
        "Esperava uma expressao ou virgula, ponto e virgula ou fechachaves.\n"
    | 80 ->
        "Esperava uma expressao.\n"
    | 81 ->
        "Esperava um operador binario ou um fecha colchete.\n"
    | 82 ->
        "Esperava um sinal de atribuicao.\n"
    | 83 ->
        "Esperava uma expressao.\n"
    | 84 ->
        "Esperava um operador binario ou virgula, ponto e virgula ou fecha chaves.\n"
    | 140 ->
        "Erro apos variavel.\n"
    | 141 ->
        "Esperava uma variavel.\n"
    | 142 ->
        "Erro apos variavel.\n"
    | 150 ->
        "Erro apos chamada de funcao.\n"
    | 39 ->
        "Esperava um ID.\n"
    | 41 ->
        "Esperava um ID.\n"
    | 42 ->
        "Esperava os argumentos da funcao.\n"
    | 138 ->
        "Esperava uma lista de expressoes.\n"
    | 43 ->
        "Espera uma lista de expressoes.\n"
    | 44 ->
        "Esperava um fecha parentese.\n"
    | 74 ->
        "Esperava uma expressao.\n"
    | 75 ->
        "Esperava um operador binario ou um fecha colchete.\n"
    | 107 ->
        "Esperava um identificador.\n"
    | 109 ->
        "Esperava o nome da funcao.\n"
    | 110 ->
        "Esperava uma lista de IDs.\n"
    | 111 ->
        "Esperava um ID.\n"
    | 113 ->
        "Esperava uma lista de IDS.\n"
    | 116 ->
        "Esperava um ID.\n"
    | 120 ->
        "Erro apos a declaracao da funcao, esperava pelo corpo.\n"
    | 122 ->
        "Erro apos o for, esperava uma ou mais atribuicoes.\n"
    | 123 ->
        "Esperava uma atribuicao.\n"
    | 163 ->
        "Esperava um IN.\n"
    | 164 ->
        "Esperava uma lista de expressoes.\n"
    | 165 ->
        "Esperava um DO.\n"
    | 166 ->
        "Esperava um bloco.\n"
    | 167 ->
        "Esperava um END.\n"
    | 124 ->
        "Esperava uma expressao.\n"
    | 125 ->
        "Esperava um operador binario ou uma virgula.\n"
    | 126 ->
        "Esperava uma expressao.\n"
    | 127 ->
        "Esperava um operador binario.\n"
    | 128 ->
        "Esperava uma expressao.\n"
    | 129 ->
        "Esperava um DO ou um Operador Binario.\n"
    | 131 ->
        "Esperava um bloco.\n"
    | 160 ->
        "Esperava um END.\n"
    | 132 ->
        "Esperava um ID.\n"
    | 133 ->
        "<MENSAGEM DE ERRO AQUI>\n"
    | 135 ->
        "Esperava um bloco.\n"
    | 158 ->
        "Esperava um end.\n"
    | 30 ->
        "Esperava uma expressão.\n"
    | 99 ->
        "Esperava um operador ou um fecha parenteses.\n"
    | 143 ->
        "Esperava argumentos, dois pontos, abre colchete ou ponto.\n"
    | _ ->
        raise Not_found
