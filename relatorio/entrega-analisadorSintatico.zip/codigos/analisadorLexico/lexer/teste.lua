--[[
comentario
de mais
de uma
linha
]]

--[[
--[[
comentario
aninhado
]]
]]


-- OPERADORES
-- soma
2 + 2
-- subtracao
2 - 2
-- multiplicacao
2 * 2
-- divisao
2 / 2
-- resto de divisao
2 % 2
-- exponenciacao
2 ^ 2

-- FLOAT
2.14

-- COMPARADORES
-- igualdade
2 == 2
-- menor igual
2 <= 2
-- maior igual
2 >= 2
-- menor
2 < 2
-- maior
2 > 2


-- inteiro
1234
23908423
123124
1032490
324932
3294

-- identificadores
identificador
m
n
i
j
k
l

-- outros tokens em lua
#
:
::
;
,
.
..
...

-- abre e fecha parentese
(
)
[
]
{
}

-- atribuicao
=

-- palavras reservadas
and
break
do
else
elseif
end
false
for
function
goto
if
in
local
nil
not
or
repeat
return
then
true
until
while

-- strings
"hello world"
"helloworld123"
"hello\\world"
"hello\"aworld"
"hello\nworld"
"hello\
world"

-- invalidos

-- _identificador

-- @
